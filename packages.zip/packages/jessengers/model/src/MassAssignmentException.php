<?php namespace Jenssegers\Model;

class MassAssignmentException extends \RuntimeException
{
}
